package com.company.Assignment1;

public class Problem2 {
    public static void main(String[] args) {
        double x = -3.5;
        double y = 1.9;
        int n = 23;
        int m = 14;
        double a = x - n / y + x + (n * y);
        System.out.println(a);
        double b = n / m + n % m;
        System.out.println(b);
        double c = n % 2 + m % 3;
        System.out.println(c);
        double d = (m + n) / 3.0;
        System.out.println(d);
        double e = (n - m) / 3;
        System.out.println(e);
        double f= (n-x)/3;
        System.out.println(f);
        double g= 1 - (1 - (1 - n));
        System.out.println(g);
        double h= m%10+(m-(n % 10));
        System.out.println(h);
    }
}
