package com.company.Assignment3;

public interface NumberFormatter {
    String format(int n);
}
